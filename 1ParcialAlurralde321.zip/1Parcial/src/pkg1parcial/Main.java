
package pkg1parcial;

import java.util.List;


public class Main {

    
    public static void main(String[] args) {
        
        Refugio refugio = new Refugio("Horizonte"); 
        
        try{
        refugio.agregarSuperviviente(new Explorador( 
                    "EXP-101", "Ada", NivelExperiencia.EXPERTO, true, 30)); 
        refugio.agregarSuperviviente(new Medico( 
                    "MED-220", "Bruno", NivelExperiencia.INTERMEDIO, true, 45)); 
        refugio.agregarSuperviviente(new Constructor( 
                    "CON-330", "Carla", NivelExperiencia.EXPERTO, true, 25)); 
        refugio.agregarSuperviviente(new Explorador( 
                    "EXP-404", "Diego", NivelExperiencia.NOVATO, true, 18)); 
        refugio.agregarSuperviviente(new Medico( 
                    "EXP-101", "Ada", NivelExperiencia.NOVATO, true, 12));
        }catch(SupervivienteDuplicadoException e){
            e.getMessage();
        }
 
        System.out.println("Supervivientes registrados:"); 
        mostrarSupervivientes(refugio.obtenerSupervivientes()); 
        System.out.println("\nAptitudes:"); 
        mostrarAptitudes(refugio.obtenerSupervivientes()); 
        System.out.println("\nAsignacion de tareas:"); 
        asignarTareas(refugio.obtenerSupervivientes()); 
        System.out.println("\nCapacitaciones:"); 
        capacitarSupervivientes(refugio.obtenerSupervivientes()); 
        System.out.println("\nDisponibles con aptitud >= 50:"); 
        mostrarSupervivientes(refugio.obtenerDisponiblesConAptitudMinima(50)); 
        System.out.println("\nSupervivientes EXPERTO:"); 
        mostrarSupervivientes(refugio.filtrarPorNivel(NivelExperiencia.EXPERTO)); 
    } 
 
    private static void mostrarSupervivientes(List<Superviviente> lista) { 
        if(lista == null){
            throw new IllegalArgumentException("La lista esta vacia");
        }else{
            for(Superviviente superviviente: lista){
                System.out.println(superviviente);
            }
        }
    } 
 
    private static void mostrarAptitudes(List<Superviviente> lista) { 
         if(lista == null){
             throw new IllegalArgumentException("La lista esta vacia");
         }else{
             for(Superviviente superviviente: lista){
                 if(superviviente.calcularAptitudMinima()>= 50){
                     System.out.println(superviviente.getNombre());
                 }
             }
         }
    } 
 
    private static void asignarTareas(List<Superviviente> lista) { 
        if(lista == null){
            throw new IllegalArgumentException("La lista esta vacia");
        }else{
            for(Superviviente superviviente: lista){
                if(superviviente instanceof Realizable){
                    System.out.println(((Realizable) superviviente).realizarTarea());
                }else{
                    System.out.println(superviviente.getNombre()+" no puede recibir tareas");
                }
            }
        }
    } 
 
    private static void capacitarSupervivientes(List<Superviviente> lista) { 
        if(lista == null){
            throw new IllegalArgumentException("La lista esta vacia");
        }else{
            for(Superviviente superviviente: lista){
                if(superviviente instanceof Capacitable){
                    System.out.println(((Capacitable) superviviente).capacitarse());
                }else{
                    System.out.println(superviviente.getNombre()+"no puede capacitarse");
                }
            }
        }
    } 
        
        
        
        
        
        
        
    
    
}
