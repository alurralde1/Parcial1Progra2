
package pkg1parcial;


public interface Capacitable {
    String capacitarse();
}
