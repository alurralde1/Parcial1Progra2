
package pkg1parcial;


public interface Realizable {
    String realizarTarea();
}
