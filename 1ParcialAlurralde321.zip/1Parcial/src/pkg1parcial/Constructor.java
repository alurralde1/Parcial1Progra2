
package pkg1parcial;


public class Constructor extends Superviviente implements Capacitable, Realizable {
    private final int habilidadTecnica;

    public Constructor(String codigo, String nombre, NivelExperiencia nivelExp, boolean disponibilidad, int habilidadTecnica) {
        super(codigo, nombre, nivelExp, disponibilidad);
        validarHabilidad(habilidadTecnica);
        this.habilidadTecnica = habilidadTecnica;
    }
    
    private static void validarHabilidad(int hab){
        if(hab <= 0){
            throw new IllegalArgumentException("La habilidad tecnica no puede ser menor o igual que cero");
        }
    }
    
    public int getHabilidadTec(){
        return habilidadTecnica;
    }

    @Override
    public String getDescription() {
        return "Constructor: [ codigo = "+getCodigo()+", nombre = "+getNombre()+", nivel = "+getNivelExp()+", disponible = "+getDisponibilidad()+", habilidadTecnica = "+habilidadTecnica+"].";
    }

    @Override
    public String capacitarse() {
        return "Se capacito a "+getNombre()+" ("+getCodigo()+")";
    }

    @Override
    public String realizarTarea() {
        return "Se asigno a: "+getNombre()+ "la tarea: mision de apoyo";
    }

    @Override
    public int calcularAptitudMinima() {
        return habilidadTecnica * 3;
    }
    
    
}
