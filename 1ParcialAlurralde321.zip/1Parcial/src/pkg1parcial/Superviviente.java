
package pkg1parcial;

import java.util.Objects;


public abstract class Superviviente {
    private final String codigo;
    private final String nombre;
    private final boolean disponibilidad;
    private final NivelExperiencia nivelExp;
    
    public Superviviente(String codigo, String nombre, NivelExperiencia nivelExp ,boolean disponibilidad){
        validarString(codigo, "El codigo no puede ser nulo o estar en blando");
        validarString(nombre, "El nombre no puede ser nulo o que este en blanco");
        validarNivel(nivelExp);
        this.codigo = codigo;
        this.nombre = nombre;
        this.nivelExp = nivelExp;
        this.disponibilidad = disponibilidad;
    }
    
    private static void validarString(String str, String mensaje){
        if(str == null || str.isBlank()){
            throw new IllegalArgumentException(mensaje);
        }
    }
    
    private static void validarNivel(NivelExperiencia nivel){
        if(nivel == null){
            throw new IllegalArgumentException("El nivel de experiencia no puede ser nulo");
        }
    }
    
    public String getCodigo(){
        return codigo;
    }
    
    public String getNombre(){
        return nombre;
    }
    
    public boolean getDisponibilidad(){
        return disponibilidad;
    }
    
    public NivelExperiencia getNivelExp(){
        return nivelExp;
    }
    
    public abstract String getDescription();
    public abstract int calcularAptitudMinima();
    
    @Override
    public String toString(){
        return getDescription();
    }
    
    @Override
    public boolean equals(Object o){
        if(o == null || !(o instanceof Superviviente s)){
            return false;
        }
        return codigo.equals(s.codigo) && nombre.equals(s.nombre);
    }
    
    @Override
    public int hashCode(){
        return Objects.hash(codigo,nombre);
    }
    
    
    
}
