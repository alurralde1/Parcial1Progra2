
package pkg1parcial;


public class SupervivienteDuplicadoException extends Exception {
    private static final String MESSAGE = "Ya existe un superviviente con el mismo codigo y el mismo nombre";
    
    public SupervivienteDuplicadoException(){
        this(MESSAGE);
    }
    
    public SupervivienteDuplicadoException(String mensaje){
        super(mensaje);
    }
}
