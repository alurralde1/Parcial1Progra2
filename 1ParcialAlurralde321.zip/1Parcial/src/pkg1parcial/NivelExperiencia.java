
package pkg1parcial;


public enum NivelExperiencia {
    NOVATO,
    INTERMEDIO,
    EXPERTO
}
