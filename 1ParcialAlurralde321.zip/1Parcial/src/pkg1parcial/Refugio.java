
package pkg1parcial;

import java.util.ArrayList;
import java.util.List;


public class Refugio {
    private final String nombre;
    private final List<Superviviente> supervivientes;
    
    public Refugio(String nombre){
        validarNombre(nombre);
        this.nombre = nombre;
        supervivientes = new ArrayList<>();
    }
    
    private static void validarNombre(String nombre){
        if(nombre == null || nombre.isBlank()){
            throw new IllegalArgumentException("El nombre no puede ser nulo y no puede estar en blanco");
        }
    }
    
    public String getName(){
        return nombre;
    }
    
    public void agregarSuperviviente(Superviviente superviviente) throws SupervivienteDuplicadoException{
        validarSuperviviente(superviviente);
        validarSupervivienteRepetido(superviviente);
        supervivientes.add(superviviente);
    }
    
    private static void validarSuperviviente(Superviviente superviviente){
        if(superviviente == null){
            throw new IllegalArgumentException("El superviviente no puede ser nulo");
        }
    }
    
    private void validarSupervivienteRepetido(Superviviente superviviente) throws SupervivienteDuplicadoException{
        if(supervivientes.contains(superviviente)){
            throw new SupervivienteDuplicadoException("No se pudo registrar: ya existe un superviviente con codigo "+superviviente.getCodigo()+" y nombre "+superviviente.getNombre()+".");
        }
    }
    
    public List<Superviviente> obtenerSupervivientes(){
        return new ArrayList<>(supervivientes);
    }
    
    public List<Superviviente> filtrarPorNivel(NivelExperiencia nivel){
        if(nivel == null){
            throw new IllegalArgumentException("El nivel no puede ser null");
        }
        
        List<Superviviente> filtrado = new ArrayList<>();
        
        for(Superviviente superviviente: supervivientes){
            if(superviviente.getNivelExp() == nivel){
                filtrado.add(superviviente);
            }
        }
        return filtrado;
    }
    
    public List<Superviviente> obtenerDisponiblesConAptitudMinima(int minimo){
        if(minimo <= 0){
            throw new IllegalArgumentException("El minimo no puede ser negativo");
        }
        
        List<Superviviente> filtrado = new ArrayList<>();
        
        for(Superviviente superviviente: supervivientes){
            if(superviviente.calcularAptitudMinima() >= minimo){
                filtrado.add(superviviente);
            }
        }
        return filtrado;
    }
    
}
