
package pkg1parcial;


public class Explorador extends Superviviente implements Realizable{
    
    private final int resistencia;

    public Explorador(String codigo, String nombre,NivelExperiencia nivelExp,boolean disponibilidad, int resistencia) {
        super(codigo, nombre, nivelExp, disponibilidad);
        validarResistencia(resistencia);
        this.resistencia = resistencia;
    }
    
    private static void validarResistencia(int res){
        if(res <= 0){
            throw new IllegalArgumentException("La resistencia no puede ser menor o igual a cero");
        }
    }
    
    public int getResistencia(){
        return resistencia;
    }

    @Override
    public String getDescription() {
        return "Explorador: [ codigo: "+getCodigo()+", nombre: "+getNombre()+", nivel: "+getNivelExp()+", disponible: "+getDisponibilidad()+", resistencia: "+resistencia+"].";
    }

    @Override
    public String realizarTarea() {
        return "Se asigno a: "+getNombre()+ "la tarea: mision de apoyo";
    }

    @Override
    public int calcularAptitudMinima() {
        return resistencia * 2;
    }
    
    
    
    
}
