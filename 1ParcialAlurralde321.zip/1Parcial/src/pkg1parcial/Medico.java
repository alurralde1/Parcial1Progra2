
package pkg1parcial;


public class Medico extends Superviviente implements Capacitable{
    private final int conocimiento;

    public Medico(String codigo, String nombre,NivelExperiencia nivelExp ,boolean disponibilidad, int conocimiento) {
        super(codigo, nombre,nivelExp ,disponibilidad);
        validarConocimiento(conocimiento);
        this.conocimiento = conocimiento;
    }
    
    private static void validarConocimiento(int con){
        if(con <= 0){
            throw new IllegalArgumentException("El conocimiento no puede ser menor o igual a cero");
        }
    }
    
    public int getConocimiento(){
        return conocimiento;
    }

    @Override
    public String getDescription() {
        return "Medico: [ codigo = "+getCodigo()+", nombre = "+getNombre()+", nivel = "+getNivelExp()+", disponibilidad = "+getDisponibilidad()+", conocimientos = "+conocimiento+"].";
    }

    @Override
    public String capacitarse() {
        return "Se capacito a "+getNombre()+" ("+getCodigo()+")";
    }

    @Override
    public int calcularAptitudMinima() {
        return conocimiento + 10;
    }
    
    
    
}
